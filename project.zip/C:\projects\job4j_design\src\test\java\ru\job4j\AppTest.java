package ru.job4j;

/**
 * Unit test for simple App.
 */
public class AppTest {
}
